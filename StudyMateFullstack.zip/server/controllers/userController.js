export const getUser = (req, res) => {
  const userId = req.params.id;
  res.json({ id: userId, name: "Demo User", role: "student" });
};

export const createUser = (req, res) => {
  const { uid, name } = req.body;
  res.status(201).json({ message: `User ${name} created`, uid });
};