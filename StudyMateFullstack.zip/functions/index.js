const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();

exports.streakReset = functions.pubsub.schedule("every day 00:00").timeZone("Asia/Kolkata").onRun(async () => {
  const users = await db.collection("users").get();
  const now = new Date();
  const updates = users.docs.map(doc => {
    const last = doc.data().lastActive?.toDate?.() || new Date("2000-01-01");
    if ((now - last) / (1000 * 60 * 60 * 24) > 1) {
      return doc.ref.update({ currentStreak: 0 });
    }
  });
  await Promise.all(updates);
  return null;
});

exports.syncParentAccess = functions.https.onCall(async (data, context) => {
  const { childId, parentId } = data;
  if (!context.auth) throw new functions.https.HttpsError("unauthenticated", "Login required");
  await db.collection("users").doc(childId).collection("parentAccess").doc(parentId).set({ granted: true });
  return { message: "Access granted" };
});

exports.generateStudyReport = functions.https.onCall(async (data, context) => {
  const uid = context.auth?.uid;
  if (!uid) throw new functions.https.HttpsError("unauthenticated", "Login required");
  const snap = await db.collection("users").doc(uid).collection("sessions").get();
  const sessions = snap.docs.map(doc => doc.data());
  const totalMinutes = sessions.reduce((sum, s) => sum + (s.duration || 0), 0);
  return { totalMinutes, sessionCount: sessions.length };
});